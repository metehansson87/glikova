import { useState } from "react";

export default function AuthPage({ onAuth }) {
  const [mode, setMode] = useState("landing"); // landing | login | signup
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onAuth && onAuth({ email, name });
    }, 900);
  };

  const handleSocial = (provider) => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onAuth && onAuth({ email: `user@${provider}.com`, name: provider });
    }, 800);
  };

  return (
    <div className="auth-shell">
      {/* Background glow */}
      <div className="auth-glow" />

      {/* Logo 3 — EKG pulse wave + blood drop */}
      <div className="auth-logo">
        <svg viewBox="0 0 96 64" fill="none" xmlns="http://www.w3.org/2000/svg" className="auth-logo-pulse">
          <defs>
            <linearGradient id="alg-wave" x1="0" y1="0" x2="96" y2="0" gradientUnits="userSpaceOnUse">
              <stop stopColor="#fca5a5" stopOpacity="0"/>
              <stop offset="0.2" stopColor="#f87171"/>
              <stop offset="0.8" stopColor="#ef4444"/>
              <stop offset="1" stopColor="#ef4444" stopOpacity="0"/>
            </linearGradient>
            <linearGradient id="alg-dot" x1="0" y1="0" x2="1" y2="1">
              <stop stopColor="#fca5a5"/>
              <stop offset="1" stopColor="#dc2626"/>
            </linearGradient>
            <filter id="auth-glow-f">
              <feGaussianBlur stdDeviation="3" result="blur"/>
              <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
            </filter>
          </defs>
          <path className="auth-wave-path" d="M4 32 H22 L28 14 L36 50 L42 24 L48 38 L54 32 H92"
            stroke="url(#alg-wave)" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
          <circle cx="48" cy="32" r="12" fill="url(#alg-dot)" filter="url(#auth-glow-f)" className="auth-dot-anim"/>
          <text x="48" y="37" textAnchor="middle" fill="white" fontSize="13" fontWeight="800" fontFamily="'Outfit',sans-serif">G</text>
        </svg>
        <span>Glikova</span>
      </div>

      {mode === "landing" && (
        <div className="auth-landing">
          <h1 className="auth-headline">Track your glucose.<br/><span className="text-green">Live better.</span></h1>
          <p className="auth-sub">Smart blood sugar monitoring designed for your life.</p>
          <div className="auth-actions">
            <button className="btn-primary" onClick={() => setMode("signup")}>Get Started — It's Free</button>
            <button className="btn-ghost" onClick={() => setMode("login")}>I already have an account</button>
          </div>
          <div className="auth-features">
            <div className="auth-feat"><span>📈</span><span>CGM Analysis</span></div>
            <div className="auth-feat"><span>🩺</span><span>AI Doctor Report</span></div>
            <div className="auth-feat"><span>🔔</span><span>Smart Alerts</span></div>
          </div>
        </div>
      )}

      {mode === "signup" && (
        <div className="auth-card">
          <h2 className="auth-card-title">Create your account</h2>
          <p className="auth-card-sub">Free forever. No credit card needed.</p>

          {/* Social buttons */}
          <div className="social-btns">
            <button className="social-btn google" onClick={() => handleSocial("google")} disabled={loading}>
              <svg viewBox="0 0 24 24" width="20" height="20"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
              Continue with Google
            </button>
            <button className="social-btn apple" onClick={() => handleSocial("apple")} disabled={loading}>
              <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>
              Continue with Apple
            </button>
          </div>

          <div className="auth-divider"><span>or sign up with email</span></div>

          <form onSubmit={handleSubmit} className="auth-form">
            <input type="text" placeholder="Full name" value={name} onChange={e => setName(e.target.value)} required />
            <input type="email" placeholder="Email address" value={email} onChange={e => setEmail(e.target.value)} required />
            <input type="password" placeholder="Password (min. 8 characters)" value={password} onChange={e => setPassword(e.target.value)} minLength={8} required />
            {error && <div className="alert error">{error}</div>}
            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? "Creating account…" : "Create Account"}
            </button>
          </form>

          <p className="auth-switch">Already have an account? <button onClick={() => setMode("login")}>Sign in</button></p>
          <p className="auth-terms">By signing up, you agree to our <a href="#">Terms</a> and <a href="#">Privacy Policy</a>.</p>
        </div>
      )}

      {mode === "login" && (
        <div className="auth-card">
          <h2 className="auth-card-title">Welcome back</h2>
          <p className="auth-card-sub">Sign in to continue tracking</p>

          <div className="social-btns">
            <button className="social-btn google" onClick={() => handleSocial("google")} disabled={loading}>
              <svg viewBox="0 0 24 24" width="20" height="20"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
              Continue with Google
            </button>
            <button className="social-btn apple" onClick={() => handleSocial("apple")} disabled={loading}>
              <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>
              Continue with Apple
            </button>
          </div>

          <div className="auth-divider"><span>or sign in with email</span></div>

          <form onSubmit={handleSubmit} className="auth-form">
            <input type="email" placeholder="Email address" value={email} onChange={e => setEmail(e.target.value)} required />
            <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} required />
            <button type="button" className="auth-forgot">Forgot password?</button>
            {error && <div className="alert error">{error}</div>}
            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? "Signing in…" : "Sign In"}
            </button>
          </form>

          <p className="auth-switch">Don't have an account? <button onClick={() => setMode("signup")}>Sign up free</button></p>
        </div>
      )}
    </div>
  );
}
