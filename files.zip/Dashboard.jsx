import { useState, useEffect } from "react";
import { useReadings } from "../hooks/useReadings";
import { useSubscription } from "../hooks/useSubscription";
import ReadingForm from "../components/ReadingForm";
import ReadingsList from "../components/ReadingsList";
import GlucoseChart from "../components/GlucoseChart";
import PaywallBanner from "../components/PaywallBanner";
import StatsBar from "../components/StatsBar";
import LanguagePicker from "../components/LanguagePicker";
import InfoPage from "./InfoPage";
import SettingsPage from "./SettingsPage";
import { T } from "../lib/i18n";

export default function Dashboard({ session }) {
  const { isPremium, loading: subLoading } = useSubscription(session);
  const { readings, loading, showPaywall, addReading, deleteReading } = useReadings(session, isPremium);
  const [unit, setUnit] = useState("mg/dL");
  const [showForm, setShowForm] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [lang, setLang] = useState("en");
  const [darkMode, setDarkMode] = useState(true);

  const t = T[lang];

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", darkMode ? "dark" : "light");
  }, [darkMode]);

  const handleSignOut = () => window.location.reload();

  if (subLoading) return null;

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="header-left">
          {/* Glikova Logo 3 — EKG pulse wave + blood drop */}
          <div className="logo-sm">
            <svg viewBox="0 0 48 32" fill="none" xmlns="http://www.w3.org/2000/svg" className="logo-pulse-svg">
              <defs>
                <linearGradient id="glg-wave" x1="0" y1="0" x2="48" y2="0" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#fca5a5" stopOpacity="0"/>
                  <stop offset="0.25" stopColor="#f87171"/>
                  <stop offset="0.75" stopColor="#ef4444"/>
                  <stop offset="1" stopColor="#ef4444" stopOpacity="0"/>
                </linearGradient>
                <linearGradient id="glg-dot" x1="0" y1="0" x2="1" y2="1">
                  <stop stopColor="#fca5a5"/>
                  <stop offset="1" stopColor="#dc2626"/>
                </linearGradient>
              </defs>
              <path className="logo-wave-path" d="M2 16 H10 L13 8 L17 24 L20 13 L23 19 L26 16 H46" stroke="url(#glg-wave)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
              <circle cx="24" cy="16" r="4" fill="url(#glg-dot)" className="logo-dot"/>
              <text x="24" y="19.5" textAnchor="middle" fill="white" fontSize="5" fontWeight="800" fontFamily="'Outfit',sans-serif">G</text>
            </svg>
          </div>
          <span className="app-title">Glikova</span>
          {isPremium && <span className="badge-premium">{t.premium}</span>}
        </div>
        <div className="header-right">
          <LanguagePicker lang={lang} onChange={setLang} />
          <div className="unit-toggle">
            <button className={unit === "mg/dL" ? "active" : ""} onClick={() => setUnit("mg/dL")}>mg/dL</button>
            <button className={unit === "mmol/L" ? "active" : ""} onClick={() => setUnit("mmol/L")}>mmol/L</button>
          </div>
        </div>
      </header>

      <main className="app-main">
        {activeTab === "dashboard" && (
          <>
            {showPaywall && !isPremium && <PaywallBanner session={session} t={t} />}
            <StatsBar readings={readings} unit={unit} t={t} />
            {readings.length > 0 && <GlucoseChart readings={readings} unit={unit} t={t} />}
          </>
        )}
        {activeTab === "history" && (
          <>
            {showPaywall && !isPremium && <PaywallBanner session={session} t={t} />}
            <ReadingsList readings={readings} unit={unit} onDelete={deleteReading} loading={loading} isPremium={isPremium} showPaywall={showPaywall} t={t} />
          </>
        )}
        {activeTab === "info" && <InfoPage lang={lang} />}
        {activeTab === "settings" && (
          <SettingsPage lang={lang} isPremium={isPremium} darkMode={darkMode} onToggleDark={() => setDarkMode(d => !d)} onSignOut={handleSignOut} />
        )}
      </main>

      {showForm && (
        <ReadingForm unit={unit} session={session} onAdd={addReading} onClose={() => setShowForm(false)} t={t} />
      )}

      <nav className="bottom-nav">
        <button className={activeTab === "dashboard" ? "nav-item active" : "nav-item"} onClick={() => setActiveTab("dashboard")}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
          <span>{lang === "tr" ? "Ana Sayfa" : "Home"}</span>
        </button>
        <button className={activeTab === "history" ? "nav-item active" : "nav-item"} onClick={() => setActiveTab("history")}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          <span>{t.history}</span>
        </button>
        <button className="nav-item add-btn" onClick={() => setShowForm(true)}>
          <div className="add-circle">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          </div>
        </button>
        <button className={activeTab === "info" ? "nav-item active" : "nav-item"} onClick={() => setActiveTab("info")}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          <span>{lang === "tr" ? "Bilgi" : "Info"}</span>
        </button>
        <button className={activeTab === "settings" ? "nav-item active" : "nav-item"} onClick={() => setActiveTab("settings")}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
          <span>{lang === "tr" ? "Ayarlar" : "Settings"}</span>
        </button>
      </nav>
    </div>
  );
}
